import java.util.Scanner;

public class Programa {

	public static void main(String[] args) {
		
		Scanner lectura = new Scanner(System.in);
	      int numeroFigura;
	      int longitudCuadrado;
	      int radioCirculo;
	      int opcion;
	      System.out.println("¿Que figura le gustaría hacer, un circulo o un cuadrado?");
	      System.out.println("Ingrese 1 para cuadrado o 0 para circulo");
	      numeroFigura = lectura.nextInt();

		
		if (numeroFigura == 1) 
		{
			System.out.println("Ingrese la longitud del lado por favor");
			longitudCuadrado = lectura.nextInt();
			System.out.println("Ingrese 1 para calcular el área, 2 para el perímetro o 3 para la diagonal del cuadrado");
			opcion = lectura.nextInt();
			if(opcion == 1)
			{
				double area = Math.pow(longitudCuadrado, 2);
				System.out.println("El area del cuadrado es: "+area);
			}
			if(opcion == 2)
			{
				int perimetro = longitudCuadrado*4;
				System.out.println("El perimetro del cuadrado es: "+perimetro);
			}
			if(opcion == 3)
			{
				double diagonal = Math.sqrt(2*longitudCuadrado*longitudCuadrado);
				System.out.println("La diagonal del cuadrado es: "+diagonal);
			}
		} 
		else {
			System.out.println("Ingrese la medida del radio");
			radioCirculo = lectura.nextInt();
			System.out.println("Ingrese 1 para calcular el área o 2 para la circunferencia (perímetro)");
			opcion = lectura.nextInt();
			if(opcion == 1)
			{
				double area = Math.PI*radioCirculo*radioCirculo;
				System.out.println("El area del circulo es: "+area);
			}
			if(opcion == 2)
			{
				double circunferencia = 2*Math.PI*radioCirculo;
				System.out.println("La circunferencia del circulo es: "+circunferencia);
			}
		}
		
	}

}
