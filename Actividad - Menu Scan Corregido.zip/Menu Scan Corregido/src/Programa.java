import java.util.Scanner;

public class Programa {

	public static void main(String[] args) {
		
 
 		String cuadro = "cuadrado";
 		String round = "circulo";
 		String area = "area";
 		String perimetro = "perimetro";
 		String circunferencia = "circunferencia";
 		String diagonal = "diagonal";
 		String nuevaLongitud, nuevoRadio, inline, inline2, inline3;
 		int newRadius, newLength;
 		
		Scanner scan = new Scanner(System.in);
		System.out.println("¿Que figura le gustaría hacer, un circulo o un cuadrado?");
		inline = scan.nextLine();
		//System.out.println(sep.contains(inline));
		
		if(cuadro.contains(inline))
		{
			Cuadrado tostadaCua = new Cuadrado();
			System.out.println("Ingrese la longitud del lado por favor");
			
			nuevaLongitud = scan.nextLine();
			newLength = Integer.parseInt(nuevaLongitud);
			 //String s = "123";
				//Int i = Integer.parseInt(s);
			tostadaCua.cambiarLongitud(newLength);
			
			System.out.println("¿Que le gustaria calcular: area, perimetro o la diagonal del cuadrado?");
			inline2 = scan.nextLine();
			//System.out.println(area.contains(inline2));
			
			if(area.contains(inline2))
			{
				System.out.println("El area del cuadrado es: "+tostadaCua.calcularArea());
			}
			else if(perimetro.contains(inline2))
			{
				System.out.println("El perimetro del cuadrado es: "+tostadaCua.calcularPerimetro());
			}
			else if(diagonal.contains(inline2))
			{
				System.out.println("La diagonal del cuadrado es: "+tostadaCua.calcularDiagonal());
			}
		}
		else if(round.contains(inline))
		{
			Circulo melonCir = new Circulo();
			System.out.println("Ingrese la medida del radio por favor");
			
			nuevoRadio = scan.nextLine();
			newRadius = Integer.parseInt(nuevoRadio);
			melonCir.cambiarRadio(newRadius);
			
			System.out.println("¿Que le gustaria calcular: area o circunferencia del circulo?");
			inline3 = scan.nextLine();
			//System.out.println(area.contains(inline2));
			
			if(area.contains(inline3))
			{
				System.out.println("El area del circulo es: "+melonCir.calcularArea());
			}
			else if(circunferencia.contains(inline3))
			{
				System.out.println("La circunferencia del circulo es: "+melonCir.calcularCircunferencia());
			}
		}
		else {
			return;
		}

	}

}
