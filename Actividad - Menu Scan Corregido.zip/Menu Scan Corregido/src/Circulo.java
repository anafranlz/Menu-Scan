
public class Circulo {

	public int radio;
	
	//Constructores (para modificar los atributos -que son variables globales-)	
	public Circulo() {
		this(177438);
	}
	public Circulo(int x) {
		this.radio = x;
	}
	//.	
	
	public double calcularArea()
	{
		return Math.PI*radio*radio;
	}
	
	public double calcularCircunferencia()
	{
		return 2*Math.PI*radio;
	}
	
	public void cambiarRadio(int x)
	{
		radio = x;
	}
	
}
