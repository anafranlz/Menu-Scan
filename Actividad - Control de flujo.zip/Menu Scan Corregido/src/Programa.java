import java.util.Scanner;

public class Programa {

	public static void main(String[] args) {
 		String nuevaLongitud, nuevoRadio, inline, inline2, inline3;
 		int newRadius, newLength, optionFigura, optionCalculo;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("¿Que figura le gustaría hacer?");
		System.out.println("1 para circulo");
		System.out.println("2 para cuadrado");
		inline = scan.nextLine();
		optionFigura = Integer.parseInt(inline);

		switch(optionFigura) {
		case 1:
			Circulo melonCir = new Circulo();
			System.out.println("Ingrese la medida del radio por favor");
			nuevoRadio = scan.nextLine();
			newRadius = Integer.parseInt(nuevoRadio);
			melonCir.cambiarRadio(newRadius);
			System.out.println("¿Que le gustaria calcular? \n1 para area \n2 para circunferencia");
			inline2 = scan.nextLine();
			optionCalculo = Integer.parseInt(inline2);
				switch(optionCalculo) {
				case 1:
					System.out.println("El area del circulo es: "+ melonCir.calcularArea());
					break;
				case 2:
					System.out.println("La circunferencia del circulo es: "+ melonCir.calcularCircunferencia());
					break;
				default:
					System.out.println("Numero invalido");
					break;
				}
			break;
		case 2:
			Cuadrado tostadaCua = new Cuadrado();
			System.out.println("Ingrese la longitud del lado por favor");
			nuevaLongitud = scan.nextLine();
			newLength = Integer.parseInt(nuevaLongitud);
			tostadaCua.cambiarLongitud(newLength);
			System.out.println("¿Que le gustaria calcular? \n1 para area \n2 para perimetro \n3 para diagonal");
			inline3 = scan.nextLine();
			optionCalculo = Integer.parseInt(inline3);
				switch(optionCalculo) {
				case 1:
					System.out.println("El area del circulo es: "+tostadaCua.calcularArea());
					break;
				case 2:
					System.out.println("El perimetro del circulo es: "+ tostadaCua.calcularPerimetro());
					break;
				case 3:
					System.out.println("La diagonal del cuadrado es: "+ tostadaCua.calcularDiagonal());
					break;
				default:
					System.out.println("Numero invalido");
					break;
				}
			break;
			default:
			System.out.println("Numero invalido");
			break;
		}
	}
}