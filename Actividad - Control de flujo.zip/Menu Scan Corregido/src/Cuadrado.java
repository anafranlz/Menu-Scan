
public class Cuadrado {

	public int longitud;

	//Constructores	
	public Cuadrado() {
		this(177438);
	}
	public Cuadrado(int x) {
		this.longitud = x;
	}
	//
	
	public double calcularArea()
	{
		return Math.pow(longitud, 2);
	}
	
	public double calcularDiagonal()
	{
		return Math.sqrt(2*longitud*longitud);
	}
	
	public int calcularPerimetro()
	{
		return longitud*4;
	}
	
	public void cambiarLongitud(int x)
	{
		longitud = x;
	}
	
}
